package com.example.adshield

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Mosaico de Ajustes rápidos: activa/desactiva el modo "permitir recompensas" por un tiempo limitado. */
class AllowRewardsTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (AdShieldState.running) {
            AdShieldState.allowUntil =
                if (AdShieldState.isAllowing) 0L
                else System.currentTimeMillis() + AdShieldState.ALLOW_WINDOW_MS
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = when {
            !AdShieldState.running -> Tile.STATE_UNAVAILABLE
            AdShieldState.isAllowing -> Tile.STATE_ACTIVE
            else -> Tile.STATE_INACTIVE
        }
        t.label = "Permitir recompensas"
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = when {
                !AdShieldState.running -> "Filtro apagado"
                AdShieldState.isAllowing -> "Anuncios permitidos"
                else -> "Anuncios bloqueados"
            }
        }
        t.updateTile()
    }
}
