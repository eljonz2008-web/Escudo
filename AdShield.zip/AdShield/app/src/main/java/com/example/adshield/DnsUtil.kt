package com.example.adshield

object DnsUtil {

    class Question(val name: String, val qType: Int, val endOffset: Int)

    /** Lee la primera pregunta de un mensaje DNS. Devuelve null si no es válido. */
    fun parseQuestion(d: ByteArray): Question? {
        if (d.size < 17) return null
        val qd = ((d[4].toInt() and 0xFF) shl 8) or (d[5].toInt() and 0xFF)
        if (qd < 1) return null
        var i = 12
        val sb = StringBuilder()
        while (true) {
            if (i >= d.size) return null
            val l = d[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if ((l and 0xC0) != 0) return null
            if (i + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, l, Charsets.US_ASCII))
            i += 1 + l
        }
        if (i + 4 > d.size) return null
        val qType = ((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)
        return Question(sb.toString(), qType, i + 4)
    }

    /**
     * Respuesta "bloqueada": para consultas A devuelve 0.0.0.0 con TTL de 5 s;
     * para el resto, respuesta vacía sin error.
     */
    fun blockedReply(q: ByteArray, question: Question): ByteArray {
        val isA = question.qType == 1
        val r = ByteArray(question.endOffset + if (isA) 16 else 0)
        System.arraycopy(q, 0, r, 0, question.endOffset)
        r[2] = (0x80 or (q[2].toInt() and 0x01)).toByte() // QR=1, conserva RD
        r[3] = 0x80.toByte()                              // RA=1, RCODE=0
        r[4] = 0; r[5] = 1                                // QDCOUNT=1
        r[6] = 0; r[7] = (if (isA) 1 else 0).toByte()     // ANCOUNT
        r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0          // NSCOUNT, ARCOUNT
        if (isA) {
            var o = question.endOffset
            r[o++] = 0xC0.toByte(); r[o++] = 0x0C          // puntero al nombre
            r[o++] = 0; r[o++] = 1                         // TYPE A
            r[o++] = 0; r[o++] = 1                         // CLASS IN
            r[o++] = 0; r[o++] = 0; r[o++] = 0; r[o++] = 5 // TTL 5 s
            r[o++] = 0; r[o++] = 4                         // RDLENGTH
            // RDATA 0.0.0.0: ya son ceros
        }
        return r
    }

    /** AdGuard DNS responde 0.0.0.0 (o REFUSED) para los dominios que bloquea. */
    fun looksBlocked(r: ByteArray): Boolean {
        if (r.size < 16) return false
        val rcode = r[3].toInt() and 0x0F
        if (rcode == 5) return true
        val an = ((r[6].toInt() and 0xFF) shl 8) or (r[7].toInt() and 0xFF)
        if (an < 1) return false
        val n = r.size
        return r[n - 4].toInt() == 0 && r[n - 3].toInt() == 0 &&
            r[n - 2].toInt() == 0 && r[n - 1].toInt() == 0
    }
}
