package com.example.adshield

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Filtro DNS local, estilo AdGuard DNS.
 * - Solo se enruta hacia el VPN el tráfico DNS (10.0.0.1); el resto de la red va directo.
 * - Cada consulta: si el dominio está en la lista propia se responde 0.0.0.0;
 *   si no, se reenvía a AdGuard DNS, que bloquea anuncios y rastreadores.
 * - Al apagar el filtro se cierra el VPN y desaparece la llave de la barra de estado.
 */
class AdVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> stopVpn()
        }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (tun != null) return
        AdShieldState.load(this)
        AdShieldState.resetCounters()

        val builder = Builder()
            .setSession("AdShield")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(DNS_ADDRESS)
            .addRoute(DNS_ADDRESS, 32)
            .setBlocking(true)

        if (AdShieldState.allApps) {
            AdShieldState.noTargets = false
        } else {
            var added = 0
            for (pkg in AdShieldState.targetPackages) {
                try {
                    builder.addAllowedApplication(pkg)
                    added++
                } catch (e: Exception) {
                    Log.w(TAG, "App no instalada: $pkg")
                }
            }
            AdShieldState.noTargets = (added == 0)
            // Si ninguna app elegida está instalada, limita el VPN a esta app para no afectar al resto.
            if (added == 0) builder.addAllowedApplication(packageName)
        }

        val fd = builder.establish() ?: return
        tun = fd
        AdShieldState.running = true
        reader = Thread({ readLoop(fd) }, "adshield-reader").also { it.start() }
    }

    private fun readLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (!Thread.currentThread().isInterrupted) {
                val len = input.read(buf)
                if (len < 0) break
                if (len == 0) continue
                val packet = buf.copyOf(len)
                pool.execute { handlePacket(packet, output) }
            }
        } catch (e: Exception) {
            Log.d(TAG, "readLoop terminó: ${e.message}")
        }
    }

    private fun handlePacket(p: ByteArray, out: FileOutputStream) {
        try {
            if (p.size < 28 || ((p[0].toInt() and 0xFF) shr 4) != 4) return // solo IPv4
            val ihl = (p[0].toInt() and 0x0F) * 4
            if (p[9].toInt() != 17) return                                  // solo UDP
            if (u16(p, ihl + 2) != 53) return                               // solo puerto 53

            val dns = p.copyOfRange(ihl + 8, p.size)
            val q = DnsUtil.parseQuestion(dns) ?: return

            var blocked = Blocklist.isBlocked(q.name)
            val reply: ByteArray? = if (blocked) {
                DnsUtil.blockedReply(dns, q)
            } else {
                forward(dns).also { if (it != null && DnsUtil.looksBlocked(it)) blocked = true }
            }
            AdShieldState.logQuery(q.name, blocked)
            if (reply == null) return

            val packetOut = buildUdpPacket(p, ihl, reply)
            synchronized(out) { out.write(packetOut) }
        } catch (e: Exception) {
            Log.d(TAG, "handlePacket: ${e.message}")
        }
    }

    /** Reenvía la consulta a AdGuard DNS (con respaldo en el servidor secundario). */
    private fun forward(dns: ByteArray): ByteArray? {
        for (server in UPSTREAM_DNS) {
            try {
                return DatagramSocket().use { s ->
                    protect(s)
                    s.soTimeout = 3000
                    s.connect(InetAddress.getByName(server), 53)
                    s.send(DatagramPacket(dns, dns.size))
                    val resp = ByteArray(4096)
                    val rp = DatagramPacket(resp, resp.size)
                    s.receive(rp)
                    resp.copyOf(rp.length)
                }
            } catch (e: Exception) {
                Log.d(TAG, "DNS $server falló: ${e.message}")
            }
        }
        return null
    }

    /** Construye un paquete IPv4+UDP de respuesta intercambiando origen y destino. */
    private fun buildUdpPacket(req: ByteArray, ihl: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val o = ByteArray(total)
        o[0] = 0x45.toByte()
        o[2] = (total shr 8).toByte(); o[3] = total.toByte()
        o[6] = 0x40.toByte()                       // no fragmentar
        o[8] = 64                                  // TTL
        o[9] = 17                                  // UDP
        System.arraycopy(req, 16, o, 12, 4)        // origen = destino original
        System.arraycopy(req, 12, o, 16, 4)        // destino = origen original
        val ck = checksum(o, 0, 20)
        o[10] = (ck shr 8).toByte(); o[11] = ck.toByte()

        System.arraycopy(req, ihl + 2, o, 20, 2)   // puerto origen = 53
        System.arraycopy(req, ihl, o, 22, 2)       // puerto destino = origen original
        val udpLen = 8 + payload.size
        o[24] = (udpLen shr 8).toByte(); o[25] = udpLen.toByte()
        // checksum UDP en 0: válido en IPv4
        System.arraycopy(payload, 0, o, 28, payload.size)
        return o
    }

    private fun u16(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0
        var i = off
        while (i < off + len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    private fun stopVpn() {
        AdShieldState.running = false
        reader?.interrupt(); reader = null
        tun?.close(); tun = null
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        pool.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val TAG = "AdShield"
        const val ACTION_STOP = "com.example.adshield.STOP"
        const val ACTION_RELOAD = "com.example.adshield.RELOAD"
        private const val VPN_ADDRESS = "10.0.0.2"
        private const val DNS_ADDRESS = "10.0.0.1"
        private val UPSTREAM_DNS = listOf("94.140.14.14", "94.140.15.15") // AdGuard DNS
    }
}
