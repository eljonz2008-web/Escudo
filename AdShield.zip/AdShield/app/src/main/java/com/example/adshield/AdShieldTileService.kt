package com.example.adshield

import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Mosaico de Ajustes rápidos, como la linterna:
 * - Encendido  = bloqueando anuncios.
 * - Apagado    = anuncios permitidos (pausa) o filtro apagado.
 * Si el filtro no está corriendo, al tocarlo lo arranca.
 */
class AdShieldTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (AdShieldState.running) {
            AdShieldState.paused = !AdShieldState.paused
        } else {
            startFilter()
        }
        refresh()
    }

    private fun startFilter() {
        if (VpnService.prepare(this) == null) {
            try {
                AdShieldState.paused = false
                startService(Intent(this, AdVpnService::class.java))
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 800)
                return
            } catch (e: Exception) {
                // plan B: abrir la app
            }
        }
        openApp()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(MainActivity.EXTRA_AUTOSTART, true)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(
                this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pi)
        } else {
            startActivityAndCollapse(i)
        }
    }

    private fun refresh() {
        val t = qsTile ?: return
        val on = AdShieldState.running && !AdShieldState.paused
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "AdShield"
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = when {
                !AdShieldState.running -> "Apagado"
                AdShieldState.paused -> "Anuncios permitidos"
                else -> "Bloqueando anuncios"
            }
        }
        t.updateTile()
    }
}
