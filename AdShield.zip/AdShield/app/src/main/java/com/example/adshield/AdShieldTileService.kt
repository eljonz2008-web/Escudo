package com.example.adshield

import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Mosaico de Ajustes rápidos, como en AdGuard:
 * - Encendido: el VPN está activo y bloquea anuncios (se ve la llave).
 * - Apagado: el VPN se cierra del todo (desaparece la llave).
 */
class AdShieldTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        if (AdShieldState.running) stopFilter() else startFilter()
        refresh()
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 800)
    }

    private fun stopFilter() {
        try {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_STOP))
        } catch (e: Exception) {
            stopService(Intent(this, AdVpnService::class.java))
        }
        AdShieldState.running = false
    }

    private fun startFilter() {
        if (VpnService.prepare(this) == null) {
            try {
                startService(Intent(this, AdVpnService::class.java))
                return
            } catch (e: Exception) {
                // plan B: abrir la app
            }
        }
        openApp()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(MainActivity.EXTRA_AUTOSTART, true)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(
                this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pi)
        } else {
            startActivityAndCollapse(i)
        }
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (AdShieldState.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "AdShield"
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = if (AdShieldState.running) "Bloqueando anuncios" else "Apagado"
        }
        t.updateTile()
    }
}
