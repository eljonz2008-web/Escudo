package com.example.adshield

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private var autostart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AdShieldState.load(this)
        autostart = intent.getBooleanExtra(EXTRA_AUTOSTART, false)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 17f }
        logView = TextView(this).apply { textSize = 12f }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        root.addView(status)
        root.addView(button("Activar filtro") { startFilter() })
        root.addView(button("Desactivar filtro") {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_STOP))
            status.postDelayed({ refresh() }, 500)
        })
        root.addView(button("Elegir app(s) a filtrar") { pickApps() })
        root.addView(button("Pausar / reanudar bloqueo") {
            if (AdShieldState.running) AdShieldState.paused = !AdShieldState.paused
            refresh()
        })
        root.addView(button("Actualizar registro DNS") { refresh() })
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })

        if (autostart) startFilter()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startFilter() {
        val permission = VpnService.prepare(this)
        if (permission != null) {
            startActivityForResult(permission, REQ_VPN)
        } else {
            launchService()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) launchService()
            else if (autostart) finish()
        }
    }

    private fun launchService() {
        AdShieldState.paused = false
        startService(Intent(this, AdVpnService::class.java))
        status.postDelayed({ refresh() }, 600)
        if (autostart) {
            autostart = false
            finish() // vuelve al juego
        }
    }

    private fun pickApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val names = apps.map { it.second }.toTypedArray()
        val selected = BooleanArray(apps.size) { apps[it].first in AdShieldState.targetPackages }

        AlertDialog.Builder(this)
            .setTitle("Apps a filtrar")
            .setMultiChoiceItems(names, selected) { _, which, checked -> selected[which] = checked }
            .setPositiveButton("Guardar") { _, _ ->
                val chosen = apps.filterIndexed { i, _ -> selected[i] }.map { it.first }
                if (chosen.isNotEmpty()) {
                    AdShieldState.saveTargets(this, chosen)
                    if (AdShieldState.running) {
                        startService(
                            Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_RELOAD)
                        )
                    }
                    status.postDelayed({ refresh() }, 600)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun refresh() {
        val sb = StringBuilder()
        sb.append(
            when {
                !AdShieldState.running -> "Filtro APAGADO"
                AdShieldState.paused -> "Filtro en PAUSA (los anuncios pasan)"
                else -> "Filtro ACTIVO (bloqueando anuncios)"
            }
        )
        sb.append("\nApps: ").append(AdShieldState.targetPackages.joinToString())
        if (AdShieldState.running && AdShieldState.noTargets) {
            sb.append("\nATENCION: ninguna app elegida esta instalada. Usa 'Elegir app(s) a filtrar'.")
        }
        status.text = sb

        val list = AdShieldState.logSnapshot()
        logView.text = if (list.isEmpty()) {
            "Aun no hay consultas DNS. Abre el juego con el filtro activo y vuelve aqui."
        } else {
            list.joinToString("\n")
        }
    }

    companion object {
        const val EXTRA_AUTOSTART = "autostart"
        private const val REQ_VPN = 1
    }
}
