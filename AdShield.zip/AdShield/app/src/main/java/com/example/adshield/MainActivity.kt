package com.example.adshield

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var blockedView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 18f }
        blockedView = TextView(this)

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        root.addView(status)
        root.addView(button("Activar filtro") { startFilter() })
        root.addView(button("Desactivar filtro") {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_STOP))
            status.postDelayed({ refresh() }, 500)
        })
        root.addView(button("Actualizar dominios bloqueados") { refresh() })
        root.addView(ScrollView(this).apply { addView(blockedView) })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startFilter() {
        val permission = VpnService.prepare(this)
        if (permission != null) {
            startActivityForResult(permission, REQ_VPN)
        } else {
            launchService()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) launchService()
    }

    private fun launchService() {
        startService(Intent(this, AdVpnService::class.java))
        status.postDelayed({ refresh() }, 600)
    }

    private fun refresh() {
        status.text = if (AdShieldState.running) {
            "Filtro ACTIVO en: " + AdShieldState.targetPackages.joinToString()
        } else {
            "Filtro apagado"
        }
        val list = AdShieldState.blockedSnapshot()
        blockedView.text = if (list.isEmpty()) "Aún no se ha bloqueado ningún dominio." else list.joinToString("\n")
    }

    companion object {
        private const val REQ_VPN = 1
    }
}
