package com.example.adshield

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var modeBtn: Button
    private var autostart = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AdShieldState.load(this)
        autostart = intent.getBooleanExtra(EXTRA_AUTOSTART, false)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        logView = TextView(this).apply { textSize = 12f }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        modeBtn = button("") { toggleAll() }

        root.addView(status)
        root.addView(button("Activar filtro") { startFilter() })
        root.addView(button("Desactivar filtro") {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_STOP))
            status.postDelayed({ refresh() }, 500)
        })
        root.addView(modeBtn)
        root.addView(button("Elegir app(s) a filtrar") { pickApps() })
        root.addView(button("Actualizar registro DNS") { refresh() })
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })

        if (autostart) startFilter()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startFilter() {
        val permission = VpnService.prepare(this)
        if (permission != null) {
            startActivityForResult(permission, REQ_VPN)
        } else {
            launchService()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) launchService()
            else if (autostart) finish()
        }
    }

    private fun launchService() {
        startService(Intent(this, AdVpnService::class.java))
        status.postDelayed({ refresh() }, 600)
        if (autostart) {
            autostart = false
            finish() // vuelve al juego
        }
    }

    private fun reloadIfRunning() {
        if (AdShieldState.running) {
            startService(Intent(this, AdVpnService::class.java).setAction(AdVpnService.ACTION_RELOAD))
        }
        status.postDelayed({ refresh() }, 600)
    }

    private fun toggleAll() {
        AdShieldState.setAllApps(this, !AdShieldState.allApps)
        reloadIfRunning()
    }

    private fun pickApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val names = apps.map { it.second }.toTypedArray()
        val selected = BooleanArray(apps.size) { apps[it].first in AdShieldState.targetPackages }

        AlertDialog.Builder(this)
            .setTitle("Apps a filtrar")
            .setMultiChoiceItems(names, selected) { _, which, checked -> selected[which] = checked }
            .setPositiveButton("Guardar") { _, _ ->
                val chosen = apps.filterIndexed { i, _ -> selected[i] }.map { it.first }
                if (chosen.isNotEmpty()) {
                    AdShieldState.saveTargets(this, chosen)
                    reloadIfRunning()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun refresh() {
        val sb = StringBuilder()
        sb.append(if (AdShieldState.running) "Filtro ACTIVO (se ve la llave de VPN)" else "Filtro APAGADO")
        sb.append("\nDNS: AdGuard DNS + lista propia")
        sb.append("\nConsultas DNS: ${AdShieldState.queryCount}  |  bloqueadas: ${AdShieldState.blockedCount}")
        if (!AdShieldState.allApps) {
            sb.append("\nApps: ").append(AdShieldState.targetPackages.joinToString())
        }
        if (AdShieldState.running && !AdShieldState.allApps && AdShieldState.noTargets) {
            sb.append("\nATENCIÓN: ninguna app elegida está instalada. Usa 'Elegir app(s) a filtrar'.")
        }
        if (AdShieldState.running && AdShieldState.queryCount == 0) {
            sb.append("\nSi juegas y las consultas siguen en 0, el DNS del juego no pasa por AdShield.")
        }
        status.text = sb

        modeBtn.text = if (AdShieldState.allApps) {
            "Modo: TODO el teléfono (tocar para cambiar)"
        } else {
            "Modo: solo apps elegidas (tocar para cambiar)"
        }

        val list = AdShieldState.logSnapshot()
        logView.text = if (list.isEmpty()) {
            "Aún no hay consultas DNS. Abre el juego con el filtro activo y vuelve aquí."
        } else {
            list.joinToString("\n")
        }
    }

    companion object {
        const val EXTRA_AUTOSTART = "autostart"
        private const val REQ_VPN = 1
    }
}
