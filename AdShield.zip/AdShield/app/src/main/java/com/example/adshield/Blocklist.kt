package com.example.adshield

/**
 * Dominios de redes publicitarias. Se bloquea el dominio y todos sus subdominios.
 * Ajusta la lista mirando "dominios bloqueados" en la app mientras juegas.
 */
object Blocklist {
    private val domains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "admob.com",
        "unityads.unity3d.com", "ads.unity3d.com",
        "applovin.com", "applvn.com",
        "ironsrc.com", "supersonicads.com",
        "vungle.com", "chartboost.com", "adcolony.com",
        "mopub.com", "inmobi.com", "startappservice.com",
        "tapjoy.com", "fyber.com", "an.facebook.com",
        "pangleglobal.com", "mintegral.com", "mbridge.com", "liftoff.io"
    )

    fun isBlocked(host: String): Boolean {
        var h = host.lowercase().trimEnd('.')
        while (true) {
            if (h in domains) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
        }
    }
}
