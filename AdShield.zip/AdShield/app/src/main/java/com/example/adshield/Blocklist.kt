package com.example.adshield

/**
 * Decide si un nombre de dominio es publicidad.
 * 1) Lista de dominios (incluye todos sus subdominios).
 * 2) Heurística: etiquetas que empiezan por ads / adserv / adnxs / adtech (ej. ads.ejemplo.com).
 */
object Blocklist {
    private val domains = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "admob.com",
        "unityads.unity3d.com", "ads.unity3d.com",
        "applovin.com", "applvn.com",
        "ironsrc.com", "supersonicads.com", "ironsource.com", "ironsource.mobi",
        "vungle.com", "liftoff.io", "tpbid.com",
        "chartboost.com", "adcolony.com", "mopub.com", "inmobi.com", "inmobi.net",
        "startappservice.com", "tapjoy.com", "fyber.com", "an.facebook.com",
        "pangleglobal.com", "pangle.io", "mintegral.com", "mbridge.com", "mtgglobals.com", "rayjump.com",
        "smaato.net", "smaato.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "openx.net", "bidswitch.net", "casalemedia.com", "moatads.com", "adsafeprotected.com",
        "ogury.com", "ogury.co", "digitalturbine.com", "bigossp.com",
        "anzu-us.com", "anzu.io", "mediation.unity3d.com",
        "googletagservices.com", "imasdk.googleapis.com"
    )

    private val labelPrefixes = listOf("ads", "adserv", "adnxs", "adtech")

    fun isBlocked(host: String): Boolean {
        val full = host.lowercase().trimEnd('.')

        var h = full
        while (true) {
            if (h in domains) return true
            val dot = h.indexOf('.')
            if (dot < 0) break
            h = h.substring(dot + 1)
        }

        val labels = full.split('.')
        if (labels.size < 2) return false
        return labels.dropLast(1).any { l -> labelPrefixes.any { l.startsWith(it) } }
    }
}
