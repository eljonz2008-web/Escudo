package com.example.adshield

import java.util.ArrayDeque

/** Estado compartido entre la actividad, el servicio VPN y el mosaico. */
object AdShieldState {

    /** Apps a las que se aplica el filtro. Verifica el nombre de paquete en la URL de Play Store. */
    val targetPackages = listOf("es.socialpoint.dragoncity")

    /** Cuánto dura el modo "permitir recompensas". */
    const val ALLOW_WINDOW_MS = 2 * 60 * 1000L

    @Volatile var running = false
    @Volatile var allowUntil = 0L

    val isAllowing: Boolean get() = System.currentTimeMillis() < allowUntil

    private val blockedLog = ArrayDeque<String>()

    @Synchronized
    fun logBlocked(domain: String) {
        if (blockedLog.size >= 60) blockedLog.removeFirst()
        blockedLog.addLast(domain)
    }

    @Synchronized
    fun blockedSnapshot(): List<String> = blockedLog.toList()
}
