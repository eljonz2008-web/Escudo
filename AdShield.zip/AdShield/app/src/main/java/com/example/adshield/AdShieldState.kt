package com.example.adshield

import android.content.Context
import java.util.ArrayDeque

/** Estado compartido entre la actividad, el servicio VPN y el mosaico. */
object AdShieldState {

    private const val PREFS = "adshield"
    private const val KEY_PKGS = "target_packages"
    private const val DEFAULT_PKG = "es.socialpoint.dragoncity"

    /** Apps a las que se aplica el filtro (se eligen desde la app). */
    @Volatile
    var targetPackages: List<String> = listOf(DEFAULT_PKG)
        private set

    @Volatile var running = false

    /** true = bloqueo en pausa: los anuncios pasan. */
    @Volatile var paused = false

    /** true = ninguna app objetivo está instalada. */
    @Volatile var noTargets = false

    fun load(ctx: Context) {
        val s = ctx.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PKGS, null)
        val list = s?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
        targetPackages = if (list.isNullOrEmpty()) listOf(DEFAULT_PKG) else list
    }

    fun saveTargets(ctx: Context, pkgs: List<String>) {
        ctx.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PKGS, pkgs.joinToString(",")).apply()
        targetPackages = pkgs
    }

    private val queries = ArrayDeque<String>()

    @Synchronized
    fun logQuery(domain: String, blocked: Boolean) {
        if (queries.size >= 80) queries.removeFirst()
        queries.addLast((if (blocked) "BLOQUEADO  " else "permitido  ") + domain)
    }

    @Synchronized
    fun logSnapshot(): List<String> = queries.toList().asReversed()
}
