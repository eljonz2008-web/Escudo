package com.example.adshield

import android.content.Context
import java.util.ArrayDeque

/** Estado compartido entre la actividad, el servicio VPN y el mosaico. */
object AdShieldState {

    private const val PREFS = "adshield"
    private const val KEY_PKGS = "target_packages"
    private const val KEY_ALL = "all_apps"
    private const val DEFAULT_PKG = "es.socialpoint.DragonCity"

    /** Apps a las que se aplica el filtro (se eligen desde la app). */
    @Volatile
    var targetPackages: List<String> = listOf(DEFAULT_PKG)
        private set

    /** true = filtrar todo el teléfono, no solo las apps elegidas. */
    @Volatile
    var allApps: Boolean = false
        private set

    @Volatile var running = false

    /** true = ninguna app elegida está instalada. */
    @Volatile var noTargets = false

    @Volatile
    var queryCount = 0
        private set

    @Volatile
    var blockedCount = 0
        private set

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        val list = p.getString(KEY_PKGS, null)
            ?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
        targetPackages = if (list.isNullOrEmpty()) listOf(DEFAULT_PKG) else list
        allApps = p.getBoolean(KEY_ALL, false)
    }

    fun saveTargets(ctx: Context, pkgs: List<String>) {
        prefs(ctx).edit().putString(KEY_PKGS, pkgs.joinToString(",")).apply()
        targetPackages = pkgs
    }

    fun setAllApps(ctx: Context, value: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_ALL, value).apply()
        allApps = value
    }

    private val queries = ArrayDeque<String>()

    @Synchronized
    fun resetCounters() {
        queries.clear()
        queryCount = 0
        blockedCount = 0
    }

    @Synchronized
    fun logQuery(domain: String, blocked: Boolean) {
        queryCount++
        if (blocked) blockedCount++
        if (queries.size >= 80) queries.removeFirst()
        queries.addLast((if (blocked) "BLOQUEADO  " else "permitido  ") + domain)
    }

    @Synchronized
    fun logSnapshot(): List<String> = queries.toList().asReversed()
}
