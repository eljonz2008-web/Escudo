# AdShield

Filtro DNS local para Android (VpnService + mosaico de Ajustes rápidos tipo linterna).

## Uso
1. Abre AdShield -> "Elegir app(s) a filtrar" -> marca tu juego -> Guardar.
2. "Activar filtro" y acepta el permiso de VPN.
3. Añade el mosaico "AdShield" a Ajustes rápidos (lápiz de editar).
4. Mosaico encendido = bloquea anuncios. Apagado = los anuncios pasan. Funciona sin salir del juego.

## Si no bloquea
- Ajustes > Red > DNS privado: ponlo en "Automático" o "Desactivado".
- Abre el juego y revisa el registro DNS de la app: los dominios "permitido" que parezcan anuncios
  hay que añadirlos en Blocklist.kt.
