# AdShield

Filtro DNS local para Android (VpnService + mosaico de Ajustes rápidos).

## Cómo abrirlo
1. Android Studio -> File > Open -> carpeta AdShield. Si pide una versión de Gradle, usa 8.7 o superior.
2. Build > Build APK(s). Instala el APK en el teléfono.

## Cómo usarlo
1. Abre AdShield y pulsa "Activar filtro" (acepta el permiso de VPN).
2. Añade el mosaico "Permitir recompensas" a Ajustes rápidos (editar mosaicos).
3. Juega normal: los anuncios quedan bloqueados.
   Cuando quieras ver un anuncio de recompensa, toca el mosaico: se permiten anuncios 2 minutos.

## Ajustes
- App objetivo y duración del modo recompensas: AdShieldState.kt
- Dominios bloqueados: Blocklist.kt (usa la lista "dominios bloqueados" de la app para afinarla)

## Limitaciones
- Si la app usa DNS cifrado propio (DoH) o si tienes "DNS privado" activo, puede saltarse el filtro.
- Bloquea por dominio: no distingue por sí mismo entre recompensa y no recompensa; por eso el mosaico.
