# AdShield

Filtro DNS local para Android, estilo AdGuard DNS (VpnService + mosaico de Ajustes rápidos).

## Uso
1. Abre AdShield. Elige la app (o activa "TODO el teléfono") y pulsa "Activar filtro".
2. Añade el mosaico "AdShield" a Ajustes rápidos (lápiz de editar).
3. Mosaico encendido = VPN activo (llave visible) y anuncios bloqueados.
   Mosaico apagado = el VPN se cierra del todo (la llave desaparece).
4. Tras activar el filtro, cierra el juego por completo y vuelve a abrirlo.

## Si no bloquea
- Mira "Consultas DNS" en la app: si sigue en 0 mientras juegas, el DNS no pasa por AdShield.
- Ajustes > Red > DNS privado: ponlo en "Automático" o "Desactivado".
- Prueba el modo "TODO el teléfono".
